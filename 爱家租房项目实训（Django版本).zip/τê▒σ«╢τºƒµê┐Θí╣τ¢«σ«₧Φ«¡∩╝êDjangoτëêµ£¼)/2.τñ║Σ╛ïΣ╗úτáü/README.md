## 项目准备注意事项

#### 1、代码仓库

<https://gitee.com/zjsharp/ihome_project_t>

#### 2、进入虚拟环境，并且安装requirements.txt

```python
pip install -r requirements.txt
```

#### 3、重新配置MySQL和Redis数据库

#### 4、确认数据库表和模型类
#### 5、执行数据库迁移文件建表，不需要创建迁移文件（迁移文件已创建）

```python
python manage.py migrate
```

#### 6、同步租房数据
```python
mysql -h ip地址 -u root -p ihome < ihome.sql(路径)
```
#### 7、使用live-server运行前端文件

```python
# 安装live-server
$ npm install -g live-server
# live-server运行前端文件
$ cd 前端文件目录
$ live-server
```

#### 8、运行爱家租房Django程序

#### 9、七牛云

https://developer.qiniu.com/

```python
# Access Key 和 Secret Key
access_key = 'n1gKo9iDzko8yrck9Zw-XyJochVHsnBWPWlbkpju'
secret_key = 'SRCV6wb1By71OnM0VHvcHbl_M3R8GmpJ_LRmWCCU'

# 要上传的空间
bucket_name = 'djangoihome'
```







#### 


